
node_id = 0
