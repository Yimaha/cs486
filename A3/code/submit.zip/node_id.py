
node_id = 0
max_depth = 0